/**
 * A statement assigning an expression to an already-declared variable
 */
public class AssignmentStmt extends Stmt {
	
	private int charNumber;
	private String symbol;
	private Expr expr;
	
	/**
	 * Construct an <code>AssignmentStmt<code> object.
	 * @param charNumber the character number
	 * @param symbol the variable
	 * @param expr the expression stored in the variable
	 */
	public AssignmentStmt(int charNumber, String symbol, Expr expr) {
		super();
		
		this.charNumber = charNumber;
		this.symbol = symbol;
		this.expr = expr;
	}
	
	/**
	 * Generate the LLVM code that should be executed to execute this statement.
	 */
	@Override
	public String toLLVM() {
		try {
			String value = SymbolTable.getInstance().getSymbolValue(symbol);
			ValueAndCode valueAndCodeExpr = expr.toLLVM();
			String code = valueAndCodeExpr.getCode();
			code += "    " + "store i32 " + valueAndCodeExpr.getValue() + ", i32* " + value + "\n";
			return code;
		} catch(Exception e) {
			Compiler.printError("Character Number [" + charNumber + "] - " + e.getMessage());
			return "";
		}
	}

}
