import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;

/**
 * Stores names of declared variables and their LLVM pointer name
 */
public class SymbolTable {
	
	private LinkedList<Map<String, String>> symbols;
    private static final SymbolTable INSTANCE = new SymbolTable();

    /**
     * Construct a <code>SymbolTable<code> object and add its first scope.
     */
    public SymbolTable() {
    	symbols = new LinkedList<Map<String, String>>();
    	//addScope();
    }

    /**
     * Get an instance of the SymbolTable.
     * @return the instance of the SymbolTable
     */
    public static SymbolTable getInstance() {
        return INSTANCE;
    }
    
    /**
     * Check if symbol is in the SymbolTable.
     * @param symbol the symbol
     * @return true if the SymbolTable contains the symbol and false otherwise
     */
    public boolean containsSymbol(String symbol) {
    	return getCurrentScope().containsKey(symbol);
    }
    
    /**
     * Get the value for a symbol from the most recent scope it's declared in.
     * @param symbol the symbol
     * @return the value for the symbol
     */
    public String getSymbolValue(String symbol) {
    	
    	String llvm = null;
    	Iterator<Map<String, String>> itr = symbols.descendingIterator();
    	while(llvm == null && itr.hasNext()) {
    		Map<String, String> tScope = itr.next();
    		if(tScope.containsKey(symbol)) {
    			llvm = tScope.get(symbol);
    		}
    	}
    	
    	return llvm;
    }
    
    /**
     * Set the value for a symbol in the SymbolTable.
     * @param symbol the symbol
     * @param value the value
     */
    public void setSymbol(String symbol, String value) {
    	if(getCurrentScope().containsKey(symbol)) throw new RuntimeException("Symbol [" + symbol + "] is already defined.");
    	getCurrentScope().put(symbol, value);
    }
    
    /**
     * Add a new scope to the symbol table.
     */
    public void addScope() {
    	symbols.add(new HashMap<String, String>());
    }
    
    /**
     * Remove the last scope from the symbol table.
     */
    public void removeScope() {
    	symbols.removeLast();
    }
    
    /**
     * Get the last scope from the symbol table.
     * @return the current scope
     */
    protected Map<String, String> getCurrentScope() {
    	return symbols.getLast();
    }
}
