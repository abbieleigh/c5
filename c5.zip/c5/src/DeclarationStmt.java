/**
 * A statement for declaring a variable.
 */
public class DeclarationStmt extends Stmt {
	
	private int charNumber;
	private String symbol;
	
	/**
	 * Construct a <code>DeclarationStmt<code> object.
	 * @param charNumber the character number
	 * @param symbol the name of the variable being declared
	 */
	public DeclarationStmt(int charNumber, String symbol) {
		super();
		
		this.charNumber = charNumber;
		this.symbol = symbol;
	}

	/**
	 * Generate the LLVM code that should be executed to execute this statement.
	 */
	@Override
	public String toLLVM() {
		try {
			String value = NameAllocator.getTempAllocator().next();
			SymbolTable.getInstance().setSymbol(symbol, value);
			return "    " + "; declaring symbol [" + symbol + "]\n    " + value + " = alloca i32\n";
		} catch(Exception e) {
			Compiler.printError("Character Number [" + charNumber + "] - " + e.getMessage());
			return "";
		}
	}

}