/**
 * A statement that is a set of 0 or more statements surrounded by curly braces.
 */
public class CompoundStmt extends Stmt {
	
	protected Stmt body;
	protected SymbolTable symbolTable;
	
	/**
	 * Construct a <code>CompoundStmt<code> object.
	 * @param body the set of 0 or more statements within the CompoundStmt's curly braces
	 */
	public CompoundStmt(Stmt body) {
		super();
		this.body = body;
		
		symbolTable = new SymbolTable();
	}

	/**
	 * Get the SymbolTable for the CompoundStmt
	 * @return the SymbolTable for the CompoundStmt
	 */
	public SymbolTable getSymbolTable() {
		return symbolTable;
	}

	/**
	 * Set the SymbolTable for the CompoundStmt
	 * @param symbolTable the new SymbolTable for the CompoundStmt
	 */
	public void setSymbolTable(SymbolTable symbolTable) {
		this.symbolTable = symbolTable;
	}

	/**
	 * Generate the LLVM code that should be executed to execute this statement.
	 */
	@Override
	public String toLLVM() {
		String llvm = "";
		SymbolTable.getInstance().addScope();
		if(body != null) {
			llvm = body.toLLVM();
		}
		SymbolTable.getInstance().removeScope();
		
		return llvm;
	}
}
