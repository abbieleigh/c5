/**
 * An Abstract Syntax Tree (AST) node representing a procedure.
 */

public class Procedure {

	private String name;
	private String argName;
	private Stmt body;

	/** Constructs a <code>Procedure</code> with specified name and body.
	 *  @param name the procedure's name
	 *  @param body the statement to execute when the procedure is called
	 */

	public Procedure(String name, String argName, Stmt body){
		this.name = name;
		this.argName = argName;
		this.body = body;
		
	}

	/** Generate the LLVM code that defines this procedure.
	 *  @return a string of LLVM code
	 */

	public String toLLVM(){
		SymbolTable.getInstance().addScope();
		String value = NameAllocator.getTempAllocator().next();
		String result = headerToLlvm(value);
		result += initializeArg(value);
		result += body.toLLVM() + "}\n";
		SymbolTable.getInstance().removeScope();
		
		return result;
	}
	
	/** Generate the LLVM code for the header of this procedure.
	 *  @return a string of LLVM code
	 */
	protected String headerToLlvm(String value) {
		String header = "define i32 @" + name;
		header += "(i32 " + value + ") {\n";
		return header;
	}
	
	/** Generate the LLVM code for the argument initialization of this procedure.
	 *  @return a string of LLVM code
	 */
	protected String initializeArg(String value) {
		String argValue = NameAllocator.getTempAllocator().next();
		SymbolTable.getInstance().setSymbol(argName, argValue);
		
		String argInit = argValue + " = alloca i32 ; parameter " + argName + "\n";
		argInit += "store i32 " + value + ", i32* " + argValue;
		
		return argInit;
	}
}
