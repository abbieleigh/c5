/**
 * An expression that's represented by a variable name.
 */
public class SymbolExpr extends Expr {
	
	private int charNumber;
	private String symbol;

	/**
	 * Construct a <code>SymbolExpr<code> object.
	 * @param charNumber the character number
	 * @param symbol the variable name
	 */
	public SymbolExpr(int charNumber, String symbol) {
		super();
		this.charNumber = charNumber;
		this.symbol = symbol;
	}

	/**
	 * Generate the LLVM code that should be executed to evaluate this expression.
	 */
	@Override
	public ValueAndCode toLLVM() {
		try {
			String symbolValue = SymbolTable.getInstance().getSymbolValue(symbol);
			String value = NameAllocator.getTempAllocator().next();
			String code = "    " + value + " = load i32, i32* " + symbolValue + "\n";
			return new ValueAndCode(value, code);
		} catch(Exception e) {
			Compiler.printError("Character Number [" + charNumber + "] - " + e.getMessage());
			return new ValueAndCode("", "");
		}
	}
}
