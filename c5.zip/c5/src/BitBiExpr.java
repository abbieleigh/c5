/**
 * An expression evaluated with two operands and a binary comparison operator.
 */
public class BitBiExpr extends BiExpr {

	/**
	 * Construct a <code>BitBiExpr<code> object.
	 * @param leftOp the left operand
	 * @param rightOp the right operand
	 * @param op the comparison operator
	 */
	public BitBiExpr(Expr leftOp, Expr rightOp, String op) {
		super(leftOp, rightOp, "icmp " + op);
	}
	
	/**
	 * Generate the LLVM code that should be executed to evaluate this expression.
	 */
	public ValueAndCode toLLVM(){
		ValueAndCode valueCode = super.toLLVM();
		
		String value = NameAllocator.getTempAllocator().next();
		String code = valueCode.getCode() +
				"    " + value + " = zext i1 " + valueCode.getValue() + " to i32" + "\n";
		return new ValueAndCode(value, code);
	}
}
