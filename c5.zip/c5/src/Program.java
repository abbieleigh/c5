import java.util.ArrayList;
import java.util.List;

/**
 * A <code>Program</code> combines together zero or more procedures.
 */

public class Program {

	private List<Procedure> procs;

	/** Constructs a <code>Program</code> with the first procedure.
	 */
	public Program(Procedure p) {
		procs = new ArrayList<Procedure>();
		procs.add(p);
	}
	
	/**
	 * Add the procedure to the program.
	 */
	public Program addProcedure(Procedure p) {
		procs.add(p);
		return this;
	}

	/**
	 * Generate the LLVM code that should be executed to execute this statement.
	 */
	public String toLLVM() {
		String body = "";
		for(Procedure p : procs) {
			body += p.toLLVM();
		}
		return body;
	}
}
