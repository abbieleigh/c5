/**
 * A statement for branching.
 */
public abstract class BranchingStmt extends Stmt {

	/**
	 * Generate the LLVM code for a conditional statement.
	 * @param label1 the label to go to if the conditional statement is true
	 * @param label2 the label to go to if the conditional statement is false
	 * @param condition the conditional expression to be evaluated
	 * @return the LLVM code for the conditional statement
	 */
	protected String generateConditionLlvm(String label1, String label2, Expr condition) {
		
		String value = NameAllocator.getTempAllocator().next();
		
		ValueAndCode valueCodeCondition = condition.toLLVM();
		String llvm = valueCodeCondition.getCode();
		llvm += value + " = icmp ne i32 " + valueCodeCondition.getValue() + ", 0";
		llvm += "br i1 " + value + ", label %" + label1 + ", label %" + label2 + "\n";
		
		return llvm;
	}
	
	/**
	 * Generate the LLVM code for a statement's body.
	 * @param label body's label
	 * @param exitLabel body's exit label
	 * @param body statement's body
	 * @return the LLVM code for the body
	 */
	protected String generateBodyLlvm(String label, String exitLabel, Stmt body) {
		String llvm = generateLabelLlvm(label);
		
		if(body != null) {
			llvm += body.toLLVM();
		}
		llvm += generateUnconditionalBranchLlvm(exitLabel);
		
		return llvm;
	}
	
	/**
	 * Generate the LLVM for an unconditional branch.
	 * @param label the name of the label
	 * @return the LLVM for the unconditional branch
	 */
	protected String generateUnconditionalBranchLlvm(String label) {
		return "br label %" + label + "\n";
	}
	
	/**
	 * Generate the LLVM for the generation of a label.
	 * @param label the name of the label
	 * @return the LLVM to generate the label
	 */
	protected String generateLabelLlvm(String label) {
		return label + ":\n";
	}
}