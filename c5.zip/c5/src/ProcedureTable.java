import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;

/**
 * Stores names of procedures and their LLVM pointer name
 */
public class ProcedureTable {
	
	private HashMap<String, Procedure> procedures;
    private static final ProcedureTable INSTANCE = new ProcedureTable();

    /**
     * Construct a <code>ProcedureTable<code> object.
     */
    public ProcedureTable() {
    	procedures = new HashMap<String, Procedure>();
    }

    /**
     * Get an instance of the ProcedureTable.
     * @return the instance of the ProcedureTable
     */
    public static ProcedureTable getInstance() {
        return INSTANCE;
    }
    
    /**
     * Check if procedure is in the Procedure Table.
     * @param procedure the procedure
     * @return true if the ProcedureTable contains the procedure and false otherwise
     */
    public boolean containsProcedure(String procedureName) {
    	return procedures.containsKey(procedureName);
    }
    
    /**
     * Get the procedure for a procedure name.
     * @param symbol the symbol
     * @return the value for the symbol
     */
    public Procedure getProcedure(String procedureName) {
    	return procedures.get(procedureName);
    }
    
    /**
     * Set the value for a procedure in the ProcedureTable.
     * @param procedureName the procedure's name
     * @param procedure the procedure
     */
    public void setProcedure(String procedureName, Procedure procedure) {
    	if(procedures.containsKey(procedureName)) throw new RuntimeException("Procedure [" + procedureName + "] is already defined.");
    	procedures.put(procedureName, procedure);
    }
    
	/** Generate the LLVM code that defines the procedures.
	 *  @return a string of LLVM code
	 */
    public String toLLVM() {
    	String result = "";
    	for (Procedure p : procedures.values()) {
    		result += p.toLLVM();
    	}
    	return result;
    }
}