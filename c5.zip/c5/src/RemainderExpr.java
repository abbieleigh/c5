/** An expression evaluated by getting the remainder from two operands.
 */

public class RemainderExpr extends BiExpr {

	/** Constructs a <code>RemainderExpr</code> with a left and right operand.
	 *  @param leftOp the left operand
	 *  @param rightOp the right operand
	 */
	public RemainderExpr(Expr leftOp, Expr rightOp){
		super(leftOp, rightOp, "srem");
	}
}