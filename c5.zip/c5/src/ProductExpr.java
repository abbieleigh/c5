/** An expression evaluated by multiplying two operands.
 */

public class ProductExpr extends BiExpr {

	/** Constructs a <code>ProductExpr</code> with a left and right operand.
	 *  @param leftOp the left operand
	 *  @param rightOp the right operand
	 */
	public ProductExpr(Expr leftOp, Expr rightOp){
		super(leftOp, rightOp, "mul");
	}
}