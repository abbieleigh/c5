
// TESTS FOR C1 THROUGH C3

// asdf \n

int main(int a) {

	println(37 - (3 + -43/5));
	println(1);
	int x, y = 10; // testing multiple declarations plus assignment within declarations
	//	int x; // testing re-declaration
	//	x = z + a + b + c + d + e; // testing greater than six errors + undeclared variables
	y = y + 1; // testing variable as expression
	println(y);



// TESTS ADDED FOR C4

 // Comparison Operators

	println(1 == 1);	// 1
	println(1 != 1);	// 0
	println(1 >= 1);	// 1
	println(1 <= 1);	// 1
	println(1 <  1);	// 0
	println(1 >  1);	// 0

	x = y > 10;			// 1
	println(x + 1);		// 2

 // Compound Statements

	{}
	{ println(5); }		// 5
	{
		println(x);		// 1
		int x = 5;
		println(x);		// 5
	}
	println(x);			// 1

 // While Statements

	while (x <= 5) {
		println(x);		// 1,2,3,4,5
		x = x + 1;
	}

	while (x > 1) x = x - 1;
	println(x);			// 1

 // If Statements

	if (x == 1) {
		println(x);		// 1
	}

	if (x + 1) {
		println(x); 	// 1
	}

	if (x != 1) {
		println(x);
	}

	if (0) {
		println(x);
	} else {
		println(0);		// 0
	}

	if (0) {
		println(0);
	}

	if (1) println(1);
	else println(0);	// 1

	if (0) println(1);
	else println(0);	// 0

// TESTS ADDED FOR C5

	println(secondProcedure(3));	//6

	return 0;
}

int secondProcedure(int x) {
	return 2*x;
}
